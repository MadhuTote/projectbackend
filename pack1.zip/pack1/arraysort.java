package pack1;
import java.util.Arrays;
public class arraysort {

	public static void main(String[] args) {
		int a[]= {20,42,32,56};
		String a1[] = {"hello","bye","takecare","goodmorning"};
		
System.out.println("original number:" + Arrays.toString(a));
Arrays.sort(a);
System.out.println("after sorting numbers are:" + Arrays.toString(a));
System.out.println("original string:" + Arrays.toString(a1));
Arrays.sort(a1);
System.out.println("af:" + Arrays.toString(a));

	}

}
