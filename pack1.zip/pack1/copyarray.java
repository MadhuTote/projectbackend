package pack1;

import java.util.Scanner;

public class copyarray {

	public static void main(String[] args) {
		int a[]={1,2,3};
		int b[]={1,2,3,4,5};
		
		int arr[]=new int[5];
		//Scanner sc=new Scanner(System.in);
		//sc.nextLine();
		
		int pos=3;
		int num=64;
		
		System.out.println("Array at specififc position : ");
		arr[pos]=num;
		for(int arr2 :arr)
			System.out.print(arr2 +" ");
			
		
		System.out.println("\nprint content of a[]:");
		
		for(int arr1: a)
		System.out.print(arr1 +" ");

		System.out.println("\nprint content of b[]");
			for(int arr2 :b)
			System.out.print(arr2 +" ");
			
			
			if(a.length>b.length)
			{
				System.out.println("\nA is longer than b");
				for(int arr1: a)
				System.out.print(arr1 +" ");}
			else
			{System.out.println("\nB is longer than A");

				for(int arr2 :b)
					System.out.print(arr2 +" ");
			}
	}

}
