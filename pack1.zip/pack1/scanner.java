package pack1;
import java.util.Scanner;  
public class scanner
{  
 public static void main(String args[]){  
   Scanner sc=new Scanner(System.in);  
     
   System.out.println("Enter your rollno");  
   int rollno=sc.nextInt();
   
   
   System.out.println("Enter your name");  
   String name=sc.nextLine();
  
   //String name=sc.next();  
   System.out.println("Enter your fee"); 
  // int fee=sc.nextInt();
   double fee=sc.nextDouble(); 
   System.out.println("Rollno:"+rollno+" name:"+name+" fee:"+fee);  
   sc.close(); 
 }  
}   
