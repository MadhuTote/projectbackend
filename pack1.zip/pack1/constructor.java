package pack1;


class demo
{
	
	public demo()
	{
		System.out.println("hello ");
		
	}	
	
}
public class constructor {

	public static void main(String[] args) {
		demo d=new demo();
		
		
		

	}

}
	
