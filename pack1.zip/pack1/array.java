package pack1;
import java.util.Arrays;
//import java.util.Arrays.*;
public class array {

	public static void main(String[] args) {
		int a[]={10,15,20,30,40};
		System.out.println("original array:" +Arrays.toString(a));
		int removeIndex=3;
		for( int i=removeIndex;i<a.length -1;i++)
		{
			a[i]=a[i+1];
		}
		System.out.println("after removing elements:" +Arrays.toString(a));
	}

}
