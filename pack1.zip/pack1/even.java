package pack1;
import java.util.Scanner;
import java.util.Scanner.*;
public class even {

	public static void main(String[] args) {
	int num,i;
	Scanner sc =new Scanner(System.in);
	System.out.println("enter a number");
	num =sc.nextInt();
//for(i=2;i<num;i++)

	if(num%2==0)
	{
		System.out.println("number is even");
	}
	else
	{
		System.out.println("odd number");
}
	}

}
