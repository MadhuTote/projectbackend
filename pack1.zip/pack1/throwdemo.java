package pack1;

public class throwdemo {
static void age(int a)
{
	if(a<18)
		throw new ArithmeticException("not valid");
	else
		System.out.println("valid");
}
	public static void main(String[] args) {
		age(12);
		System.out.println("end");
		
	}

}
