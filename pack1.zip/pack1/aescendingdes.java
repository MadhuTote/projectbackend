package pack1;

import java.util.Iterator;
import java.util.TreeSet;

public class aescendingdes {

	public static void main(String[] args) {
//		LinkedList<Integer> ar = new LinkedList<Integer>();

	//	ar.add(10);
		//ar.add(15);
		//ar.add(42);
		//ar.add(12);
		
	}
	//Iterator itr = ar.iterator();
	//Collections.sort(ar);


}
