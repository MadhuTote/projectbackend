package pack1;

import java.util.Scanner;
public class exception {

	public static void main(String[] args) {
		try
		{
		int x;
	    int num=40;
		int a[]=new int[4];
		System.out.println("enter a dividisor");
		Scanner sc=new Scanner(System.in);
		x=sc.nextInt();
		
		//	int q =num/x;
		a[2] = num/x;
		System.out.println(a[2]);
		//System.out.println(q);
		}
		catch(ArrayIndexOutOfBoundsException ex)
		{
			System.out.println(ex.getMessage());
			System.out.println("Array index is out of limit");
		}
		catch(ArithmeticException e)
		{
			System.out.println(e.getMessage());
			
		}
		finally{
	System.out.println("object destroy");
		
	}
	
	}}

