package pack1;
class def
{
	int price;
	String product_name;
	def(int i,String s)
	{
		price=i;
		product_name =s;
	}
	 void show()
	 {
		 System.out.println(price+""+product_name);
	 }
}

public class d1 {

	public static void main(String[] args) {
		def d=new def(500,"icecream");
		d.show();

	}

}
