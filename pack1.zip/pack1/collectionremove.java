package pack1;
import java.util.*;
public class collectionremove {

	public static void main(String[] args) {
	
		LinkedList<Integer> ar= new LinkedList<Integer>();
		ar.add(34);
		ar.add(24);
		ar.add(90);
		ar.add(55);
		ar.add(34);
		//System.out.println("The  element to be remove now is 34:");
		System.out.println("The  elements before sort are:");
		//System.out.println("10 is in the list:" + list.remove("10"));

		Iterator itr = ar.iterator();
		while(itr.hasNext())
		{
		System.out.println(itr.next());
		}
Collections.sort(ar);
		//ar.remove(4);
		//ar.remove(3);
		System.out.println("The sorted elements are:");
		Iterator itr2 = ar.iterator();
		while(itr2.hasNext())
		{
		System.out.println(itr2.next());
		}
		
		Collections.reverse(ar);
		System.out.println("The reverse elements are:");
		Iterator itr3 = ar.iterator();
		while(itr3.hasNext())
		{
		System.out.println(itr3.next());
		}

		}
}


	


