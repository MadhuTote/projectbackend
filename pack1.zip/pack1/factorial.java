package pack1;

import java.util.Scanner;

public class factorial {

	public static void main(String[] args) {
		
			  int i,fact=1,num;  
			
			  Scanner sc=new Scanner(System.in);
				System.out.println("enter a number");
				num=sc.nextInt();  
			  for(i=1;i<=num;i++){    
			      fact=fact*i;    
			  }    
			  System.out.println("Factorial of "+num+" is: "+fact);    
			 }  
			}  
	

