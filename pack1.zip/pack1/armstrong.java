
package pack1;

import java.util.Scanner;

public class armstrong {

	public static void main(String[] args) { 
			 
			    int c=0,a,temp,num;  
			    Scanner sc=new Scanner(System.in);
				System.out.println("enter a number");
				num=sc.nextInt();
			  // int n=153;//It is the number to check armstrong  
			    temp=num;  
			    while(num>0)  
			    {  
			    a=num%10;  
			    num=num/10;  
			    c=c+(a*a*a);  
			    }  
			    if(temp==c)  
			    System.out.println("armstrong number");   
			    else  
			        System.out.println("Not armstrong number");   
			   }  
			}  
	


