package pack1;

public class abc {
int i,j;
	public static void main(String[] args) {
		/*
		 * for(int i=5;i>0;i--) //for(int i=1;i<=5;i++) { for(int j=0;j<i;j++)
		 * //for(int j=0;j<i;j++) { //System.out.println(j+1);
		 * System.out.println(j+1);
		 * 
		 * System.out.println("");
		 * 
		 * } }
		 */

		// 123456789
		/*int t = 2;

		for (int i = 1; i <= 20; i = i + 2) {
			System.out.println(t * i);
		}

	}
}*/
	//for(int j = 0; j <5;j++)
	//{
		for(int i = 1;i<=5;i++) // for 1,123same
		{
			for(int j=5;j>=i;j--){// and 5,543 this fakt 123 sathi j=1;j<=i;j++;
			System.out.print(j);
		}
		System.out.println("\n");
	}	}
}
		/*
		 * for(int i=1;i<=10;i++){ System.out.println("i want " +i +
		 * " icecream"); }
		 */
