package pack1;

import java.util.*;

public class collection {

	public static void main(String[] args) {
		TreeSet<Integer> ar = new TreeSet<Integer>();

		ar.add(1);
		ar.add(5);
		ar.add(4);
		ar.add(10);
		ar.add(2);
		ar.add(1);
		//int sum = 0;
		Iterator itr = ar.iterator();

	//	 Collections.sort(ar);
		//Collections.reverse(ar);
		
		//while (itr.hasNext()) {
			//System.out.println(sum);
			//sum = sum + (int) itr.next();}
			//System.out.println(sum);
	
		//System.out.println("reverse:");
		//Collections.reverse (ar);
		//Iterator itr = ar.iterator();
		while(itr.hasNext()) 
		{
		System.out.println(itr.next());
		}
	
		 
	
}}
